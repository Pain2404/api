﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Bio
    {
        public string name { get; set; }
        public string birthDate { get; set; }
        public string birthPlace { get; set; }
        public string gender { get; set; } 
        public string realName { get; set; }
    }
}
