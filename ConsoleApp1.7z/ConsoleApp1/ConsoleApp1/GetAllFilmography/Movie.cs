﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Movie
    {
        public string status { get; set; }
        public string title { get; set; }
        public string titleType { get; set; }
        public string year { get; set; }
    }
}
