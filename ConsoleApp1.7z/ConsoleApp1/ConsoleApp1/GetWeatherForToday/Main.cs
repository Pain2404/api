﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Main
    {
        public string feels_like { get; set; }
        public string temp_max { get; set; }
        public string temp_min { get; set; }
    }
}
