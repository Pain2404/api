﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Translator
    {
        HttpClient client = new HttpClient();
        string url = "https://google-translate1.p.rapidapi.com/language/translate/v2";
        public void Translate()
        {
            TranslatedText body = new TranslatedText()
            {
                q = "Привет",
                target = "en",
                source = "ru"
            };
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Headers.Add("X-RapidAPI-Host", "google-translate1.p.rapidapi.com");
            request.Headers.Add("X-RapidAPI-Key", "9f92fb5492msh2e4f028835a7dd7p146468jsn9a7239a6a0d8");

            request.Content = new StringContent(JsonConvert.SerializeObject(body));
            var response = client.SendAsync(request).Result;
            string responseBody = response.Content.ReadAsStringAsync().Result;
            Console.WriteLine(responseBody);
        }
    }
}
