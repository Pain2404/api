﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Venue
    {
        public string name { get; set; }
        public string surface { get; set; }
        public string city { get; set; }
        public string capacity { get; set; }
    }
}
