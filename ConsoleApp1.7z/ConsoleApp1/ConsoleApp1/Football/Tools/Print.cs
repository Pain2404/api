﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Print
    {
        public void Print_()
        {
                Console.WriteLine("Choose the option: \n 1.Get all leagues \n 2.Get teams by id and year \n 3.Get team by name \n 4.Get players by team");
        }
    }
}
