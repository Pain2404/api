﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Birth
    {
        public string date { get; set; }
        public string place { get; set; }
        public string country { get; set; }
    }
}
